@extends('layouts.app')

@section('title', 'Laporan')

@section('content')
<div class="container">
    <h4>Laporan</h4>
    <div style="background:#fff; padding:15px; border-radius:8px;">
        <p>Placeholder: Papar laporan murid di sini.</p>
    </div>
</div>
@endsection
