<?php $__env->startSection('title', 'Senarai Murid'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <div class="row mt-4">
        <div class="col-12">
            <div class="card shadow-sm border-0 rounded-4">
                <div class="card-header bg-primary text-white fw-semibold">
                    <i class="bi bi-people-fill me-2"></i> Senarai Murid
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <a href="<?php echo e(route('guru.addMurid')); ?>" class="btn btn-primary">
                            <i class="bi bi-person-plus me-1"></i>Tambah Murid
                        </a>
                    </div>

                    <form method="POST" action="<?php echo e(route('guru.bulkAction')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php if($murid->count()): ?>
                            <table class="table table-striped align-middle">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>MyKid ID</th>
                                        <th>Nama Murid</th>
                                        <th>Kelas</th>
                                        <th>Tarikh Lahir</th>
                                        <th>Alamat</th>
                                        <th>Pilih</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $murid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($index + 1); ?></td>
                                            <td><?php echo e($m->MyKidID); ?></td>
                                            <td><?php echo e($m->namaMurid); ?></td>
                                            <td><?php echo e($m->kelas); ?></td>
                                            <td><?php echo e($m->tarikhLahir ? date('d/m/Y', strtotime($m->tarikhLahir)) : '-'); ?></td>
                                            <td><?php echo e($m->alamat); ?></td>
                                            <td><input type="checkbox" name="selected_murid[]" value="<?php echo e($m->MyKidID); ?>"></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div class="mt-3">
                                <button type="submit" name="action" value="edit" class="btn btn-warning">Edit </button>
                                <button type="submit" name="action" value="delete" class="btn btn-danger">Padam </button>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info">
                                <i class="bi bi-info-circle me-2"></i>
                                <strong>Tiada murid didaftarkan lagi.</strong><br>
                                Klik butang "Tambah Murid" di atas untuk mula mendaftarkan murid baru.
                            </div>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pastisumayyah\resources\views/guru/senaraiMurid.blade.php ENDPATH**/ ?>