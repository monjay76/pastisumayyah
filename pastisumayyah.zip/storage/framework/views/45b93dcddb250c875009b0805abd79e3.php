<?php $__env->startSection('title', 'Pendaftaran Akaun'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <div class="row mt-4">
        <div class="col-12 col-lg-8 mx-auto">
            <div class="card shadow-sm border-0 rounded-4">
                <div class="card-header bg-success text-white fw-semibold">
                    <i class="bi bi-person-plus-fill me-2"></i> Pendaftaran Akaun Pengguna
                </div>
                <div class="card-body p-4">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php if(!request('role')): ?>
                        <h5>Pilih Peranan</h5>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <a href="<?php echo e(route('pentadbir.createUser', ['role' => 'guru'])); ?>" class="btn btn-outline-primary w-100">
                                    <i class="bi bi-person-badge me-2"></i> Guru
                                </a>
                            </div>
                            <div class="col-md-6 mb-3">
                                <a href="<?php echo e(route('pentadbir.createUser', ['role' => 'ibubapa'])); ?>" class="btn btn-outline-primary w-100">
                                    <i class="bi bi-house-heart me-2"></i> Ibu Bapa
                                </a>
                            </div>
                        </div>
                        <div class="mt-3">
                            <a href="<?php echo e(route('pentadbir.createUser')); ?>" class="btn btn-secondary">
                                <i class="bi bi-arrow-left"></i> Kembali
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="mb-3">
                            <a href="<?php echo e(route('pentadbir.createUser')); ?>" class="btn btn-secondary">
                                <i class="bi bi-arrow-left"></i> Pilih Peranan Lain
                            </a>
                        </div>

                        <form action="<?php echo e(route('pentadbir.storeUser')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul class="mb-0">
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <input type="hidden" name="role" value="<?php echo e(request('role')); ?>">
                            <div class="row g-3">
                                <?php if(request('role') === 'guru'): ?>
                                    <div class="col-md-6">
                                        <label class="form-label">ID Guru</label>
                                        <input type="text" name="ID_Guru" class="form-control" value="<?php echo e(old('ID_Guru')); ?>" placeholder="Contoh: GURU001" required>
                                        <?php $__errorArgs = ['ID_Guru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-md-6">
                                        <label class="form-label">Nama Guru</label>
                                        <input type="text" name="namaGuru" class="form-control" value="<?php echo e(old('namaGuru')); ?>" placeholder="Contoh: Nur Aisyah Binti Ali" required>
                                        <?php $__errorArgs = ['namaGuru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Jawatan</label>
                                        <input type="text" name="jawatan" class="form-control" value="<?php echo e(old('jawatan')); ?>" placeholder="Contoh: Guru Bahasa Melayu" required>
                                        <?php $__errorArgs = ['jawatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                <?php elseif(request('role') === 'ibubapa'): ?>
                                    <div class="col-md-6">
                                        <label class="form-label">No. Kad Pengenalan</label>
                                        <input type="text" name="ID_Parent" class="form-control" value="<?php echo e(old('ID_Parent')); ?>" placeholder="Tanpa simbol '-' " required>
                                        <?php $__errorArgs = ['ID_Parent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Nama Ibu Bapa</label>
                                        <input type="text" name="namaParent" class="form-control" value="<?php echo e(old('namaParent')); ?>" placeholder="Contoh: Nur Aisyah Binti Ali" required>
                                        <?php $__errorArgs = ['namaParent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                <?php endif; ?>

                                <div class="col-md-6">
                                    <label class="form-label">Emel</label>
                                    <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" placeholder="Contoh: aisyah@gmail.com" required>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label">No. Tel</label>
                                    <input type="text" name="noTel" class="form-control" value="<?php echo e(old('noTel')); ?>" placeholder="Contoh: 012-3456789" required>
                                    <?php $__errorArgs = ['noTel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label">Kata Laluan</label>
                                    <input type="password" name="password" class="form-control" required>
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="d-flex justify-content-end mt-4">
                                <button type="submit" class="btn btn-success px-4">
                                    <i class="bi bi-save2 me-1"></i> Daftar Akaun
                                </button>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>
            </div>

            
            <div class="card mt-4 shadow-sm border-0 rounded-4">
                <div class="card-header bg-light fw-semibold">
                    <i class="bi bi-people-fill me-2 text-success"></i> Senarai Akaun Pengguna
                </div>
                <div class="card-body">
                    <?php if($users->count()): ?>
                        <table class="table table-striped align-middle">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Nama</th>
                                    <th>Emel</th>
                                    <th>Peranan</th>
                                    <th>Tarikh Daftar</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td class="text-capitalize"><?php echo e($user->role); ?></td>
                                        <td><?php echo e($user->created_at->format('d/m/Y')); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p class="text-muted mb-0">Tiada akaun didaftarkan lagi.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pastisumayyah\resources\views/pentadbir/daftarAkaun.blade.php ENDPATH**/ ?>