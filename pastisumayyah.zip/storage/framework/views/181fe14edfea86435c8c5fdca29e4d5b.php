<?php $__env->startSection('title', 'Prestasi Murid - Guru'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <div class="row mt-4">
        <div class="col-12">
            <!-- Navigation Tabs - Guru version (only Penilaian Prestasi) -->
            <div class="card shadow-sm border-0 rounded-4 mb-4">
                <div class="card-header bg-primary text-white">
                    <ul class="nav nav-tabs card-header-tabs" id="mainTabs" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active text-white" id="assessment-tab" data-bs-toggle="tab" data-bs-target="#assessment" type="button" role="tab" aria-controls="assessment" aria-selected="true">
                                <i class="bi bi-pencil-square me-2"></i>Penilaian Prestasi
                            </button>
                        </li>
                    </ul>
                </div>
                <div class="card-body">
                    <div class="tab-content" id="mainTabsContent">
                        <!-- Assessment Tab -->
                        <div class="tab-pane fade show active" id="assessment" role="tabpanel" aria-labelledby="assessment-tab">
                            <!-- Selection Section -->
                            <div class="card shadow-sm border-0 rounded-4 mb-4">
                                <div class="card-header bg-info text-white fw-semibold">
                                    <i class="bi bi-filter me-2"></i> Pilih Kelas, Murid & Subjek
                                </div>
                                <div class="card-body">
                                    <form method="GET" action="<?php echo e(route('guru.prestasiMurid')); ?>" id="filterForm">
                                        <div class="row g-3">
                                            <!-- Select Class -->
                                            <div class="col-md-4">
                                                <label for="kelas" class="form-label fw-semibold">Pilih Kelas</label>
                                                <select name="kelas" id="kelas" class="form-select" required onchange="this.form.submit()">
                                                    <option value="">-- Pilih Kelas --</option>
                                    <?php if(is_array($classes) || $classes instanceof \Illuminate\Support\Collection): ?>
                                        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($kelas); ?>" <?php echo e($selectedClass == $kelas ? 'selected' : ''); ?>>
                                                <?php echo e($kelas); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                                </select>
                                            </div>

                                            <!-- Select Student -->
                                            <div class="col-md-4">
                                                <label for="murid" class="form-label fw-semibold">Pilih Murid</label>
                                                <select name="murid" id="murid" class="form-select" <?php echo e(!$selectedClass ? 'disabled' : ''); ?> onchange="this.form.submit()">
                                                    <option value="">-- Pilih Murid --</option>
                                                    <?php if(is_array($students) || $students instanceof \Illuminate\Support\Collection): ?>
                                                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($student->MyKidID); ?>" <?php echo e($selectedStudent && $selectedStudent->MyKidID == $student->MyKidID ? 'selected' : ''); ?>>
                                                                <?php echo e($student->namaMurid); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </select>
                                            </div>

                                            <!-- Select Subject -->
                                            <div class="col-md-4">
                                                <label for="subjek" class="form-label fw-semibold">Pilih Subjek</label>
                                                <select name="subjek" id="subjek" class="form-select" <?php echo e(!$selectedStudent ? 'disabled' : ''); ?> onchange="this.form.submit()">
                                                    <option value="">-- Pilih Subjek --</option>
                                                    <?php if(is_array($subjekList) || $subjekList instanceof \Illuminate\Support\Collection): ?>
                                                        <?php $__currentLoopData = $subjekList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subjek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($subjek); ?>" <?php echo e($selectedSubjek == $subjek ? 'selected' : ''); ?>>
                                                                <?php echo e($subjek); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                        </div>
                                    </form>

                                    <?php if($selectedClass && $selectedStudent && $selectedSubjek): ?>
                                        <div class="alert alert-info mt-3 mb-0">
                                            <i class="bi bi-info-circle me-2"></i>
                                            <strong>Dipilih:</strong> Kelas <?php echo e($selectedClass); ?> | <?php echo e($selectedStudent->namaMurid); ?> | <?php echo e($selectedSubjek); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Assessment Form Section -->
                            <?php if($selectedClass && $selectedStudent && $selectedSubjek): ?>
                                <?php
                                    $isPratahfiz = strtolower($selectedSubjek) == 'pra tahfiz' || strtolower($selectedSubjek) == 'pratahfiz';
                                    $isNurulQuran = strtolower($selectedSubjek) == 'nurul quran';
                                    $isGeneralSubject = in_array(strtolower($selectedSubjek), [
                                        'bahasa malaysia', 'bahasa inggeris', 'matematik',
                                        'sains', 'jawi', 'peribadi muslim', 'arab'
                                    ]);
                                ?>
                                <div class="card shadow-sm border-0 rounded-4 mb-4">
                                    <div class="card-header bg-success text-white fw-semibold">
                                        <i class="bi bi-pencil-square me-2"></i>
                                        <?php echo e($isPratahfiz ? 'Penilaian Prestasi - Pratahfiz' : ($isNurulQuran ? 'Penilaian Prestasi - Nurul Quran' : 'Penilaian Prestasi - ' . $selectedSubjek)); ?>

                                    </div>
                                    <div class="card-body">
                                        <?php if(session('success')): ?>
                                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                                <i class="bi bi-check-circle me-2"></i><?php echo e(session('success')); ?>

                                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                            </div>
                                        <?php endif; ?>

                                        <?php if(session('error')): ?>
                                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                                <i class="bi bi-exclamation-triangle me-2"></i><?php echo e(session('error')); ?>

                                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                            </div>
                                        <?php endif; ?>

                                        <form method="POST" action="<?php echo e(route('guru.prestasiMurid.store')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="murid_id" value="<?php echo e($selectedStudent->MyKidID); ?>">
                                            <input type="hidden" name="subject_id" id="subject_id" value="">
                                            <input type="hidden" name="penggal" id="penggalInput" value="">

                                            <!-- Select Penggal -->
                                            <div class="mb-4">
                                                <label for="penggal" class="form-label fw-bold">Pilih Penggal</label>
                                                <select name="penggal_display" id="penggal" class="form-select w-auto" required onchange="updatePenggalValue()">
                                                    <option value="">-- Pilih Penggal --</option>
                                                    <option value="1">Penggal 1</option>
                                                    <option value="2">Penggal 2</option>
                                                </select>
                                            </div>

                                            <!-- Assessment Table -->
                                            <div class="table-responsive">
                                                <table class="table table-bordered table-hover align-middle">
                                                    <thead class="table-primary">
                                                        <tr>
                                                            <th class="text-center" style="width: 10%;">No.</th>
                                                            <th class="text-center" style="width: 25%;">
                                                                <?php if($isPratahfiz): ?>
                                                                    Pratahfiz Surah Lazim
                                                                <?php elseif($isNurulQuran): ?>
                                                                    Bacaan Wajib Nurul Quran
                                                                <?php elseif($isGeneralSubject): ?>
                                                                    Kriteria Penilaian
                                                                <?php else: ?>
                                                                    Ayat
                                                                <?php endif; ?>
                                                            </th>
                                                            <th class="text-center" style="width: 65%;">Tahap Pencapaian</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php if($isNurulQuran): ?>
                                                            
                                                            <?php
                                                                $nurulQuranUnits = [
                                                                    'Unit 1 : Mukasurat 1 - 29',
                                                                    'Unit 1 : Mukasurat 29 - 40',
                                                                    'Unit 2 : Mukasurat 42 - 53',
                                                                    'Unit 2 : Mukasurat 54 - 64'
                                                                ];
                                                            ?>
                                                            <?php $__currentLoopData = $nurulQuranUnits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unitIndex => $unitLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php
                                                                    $itemLabel = 'Buku 1 - ' . $unitLabel;
                                                                    $itemId = 'NQ_Buku1_Unit' . ($unitIndex + 1);
                                                                    $penggal1Key = $itemLabel . '_Penggal 1';
                                                                    $penggal2Key = $itemLabel . '_Penggal 2';
                                                                    $penggal1 = $prestasi->has($penggal1Key) ? $prestasi->get($penggal1Key)->first() : null;
                                                                    $penggal2 = $prestasi->has($penggal2Key) ? $prestasi->get($penggal2Key)->first() : null;
                                                                ?>
                                                                <tr>
                                                                    <?php if($unitIndex == 0): ?>
                                                                    <td class="text-center fw-semibold align-middle" rowspan="4">
                                                                        <span class="d-flex align-items-center justify-content-center h-100">Buku 1</span>
                                                                    </td>
                                                                    <?php endif; ?>
                                                                    <td class="fw-semibold"><?php echo e($unitLabel); ?></td>
                                                                    <td>
                                                                        <div class="d-flex justify-content-center gap-3">
                                                                            <div class="form-check">
                                                                                <input class="form-check-input" type="radio"
                                                                                       name="assessments[<?php echo e($itemLabel); ?>]"
                                                                                       value="1"
                                                                                       id="item<?php echo e($itemId); ?>_1">
                                                                                <label class="form-check-label" for="item<?php echo e($itemId); ?>_1">
                                                                                    <span class="badge bg-warning text-dark">1</span> Ansur Maju
                                                                                </label>
                                                                            </div>
                                                                            <div class="form-check">
                                                                                <input class="form-check-input" type="radio"
                                                                                       name="assessments[<?php echo e($itemLabel); ?>]"
                                                                                       value="2"
                                                                                       id="item<?php echo e($itemId); ?>_2">
                                                                                <label class="form-check-label" for="item<?php echo e($itemId); ?>_2">
                                                                                    <span class="badge bg-info text-dark">2</span> Maju
                                                                                </label>
                                                                            </div>
                                                                            <div class="form-check">
                                                                                <input class="form-check-input" type="radio"
                                                                                       name="assessments[<?php echo e($itemLabel); ?>]"
                                                                                       value="3"
                                                                                       id="item<?php echo e($itemId); ?>_3">
                                                                                <label class="form-check-label" for="item<?php echo e($itemId); ?>_3">
                                                                                    <span class="badge bg-success">3</span> Sangat Maju
                                                                                </label>
                                                                            </div>
                                                                        </div>
                                                                        <?php if($penggal1 || $penggal2): ?>
                                                                            <div class="mt-2 small text-muted">
                                                                                <?php if($penggal1): ?>
                                                                                    <span class="me-3"><strong>P1:</strong>
                                                                                        <?php if($penggal1->markah == 1): ?>
                                                                                            <span class="badge bg-warning text-dark">1</span>
                                                                                        <?php elseif($penggal1->markah == 2): ?>
                                                                                            <span class="badge bg-info text-dark">2</span>
                                                                                        <?php else: ?>
                                                                                            <span class="badge bg-success">3</span>
                                                                                        <?php endif; ?>
                                                                                    </span>
                                                                                <?php endif; ?>
                                                                                <?php if($penggal2): ?>
                                                                                    <span><strong>P2:</strong>
                                                                                        <?php if($penggal2->markah == '1'): ?>
                                                                                            <span class="badge bg-warning text-dark">1</span>
                                                                                        <?php elseif($penggal2->markah == '2'): ?>
                                                                                            <span class="badge bg-info text-dark">M</span>
                                                                                        <?php else: ?>
                                                                                            <span class="badge bg-success">SM</span>
                                                                                        <?php endif; ?>
                                                                                    </span>
                                                                                <?php endif; ?>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php elseif($isGeneralSubject): ?>
                                                            
                                                            <?php
                                                                $generalCriteria = [
                                                                    'Pengecaman & Kenal Huruf/Nombor',
                                                                    'Sebutan & Bunyi',
                                                                    'Kemahiran Membaca',
                                                                    'Kemahiran Menulis',
                                                                    'Kefahaman & Aplikasi'
                                                                ];
                                                            ?>
                                                            <?php $__currentLoopData = $generalCriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $criteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php
                                                                    $itemLabel = $criteria;
                                                                    $itemId = str_replace([' ', '&'], '_', $criteria);
                                                                    $penggal1Key = $itemLabel . '_Penggal 1';
                                                                    $penggal2Key = $itemLabel . '_Penggal 2';
                                                                    $penggal1 = $prestasi->has($penggal1Key) ? $prestasi->get($penggal1Key)->first() : null;
                                                                    $penggal2 = $prestasi->has($penggal2Key) ? $prestasi->get($penggal2Key)->first() : null;
                                                                ?>
                                                                <tr>
                                                                    <td class="text-center fw-semibold"><?php echo e($index + 1); ?></td>
                                                                    <td class="fw-semibold"><?php echo e($itemLabel); ?></td>
                                                                    <td>
                                                                        <div class="d-flex justify-content-center gap-3">
                                                                            <div class="form-check">
                                                                                <input class="form-check-input" type="radio"
                                                                                       name="assessments[<?php echo e($itemLabel); ?>]"
                                                                                       value="1"
                                                                                       id="item<?php echo e($itemId); ?>_1">
                                                                                <label class="form-check-label" for="item<?php echo e($itemId); ?>_1">
                                                                                    <span class="badge bg-warning text-dark">1</span> Ansur Maju
                                                                                </label>
                                                                            </div>
                                                                            <div class="form-check">
                                                                                <input class="form-check-input" type="radio"
                                                                                       name="assessments[<?php echo e($itemLabel); ?>]"
                                                                                       value="2"
                                                                                       id="item<?php echo e($itemId); ?>_2">
                                                                                <label class="form-check-label" for="item<?php echo e($itemId); ?>_2">
                                                                                    <span class="badge bg-info text-dark">2</span> Maju
                                                                                </label>
                                                                            </div>
                                                                            <div class="form-check">
                                                                                <input class="form-check-input" type="radio"
                                                                                       name="assessments[<?php echo e($itemLabel); ?>]"
                                                                                       value="3"
                                                                                       id="item<?php echo e($itemId); ?>_3">
                                                                                <label class="form-check-label" for="item<?php echo e($itemId); ?>_3">
                                                                                    <span class="badge bg-success">3</span> Sangat Maju
                                                                                </label>
                                                                            </div>
                                                                        </div>
                                                                        <?php if($penggal1 || $penggal2): ?>
                                                                            <div class="mt-2 small text-muted">
                                                                                <?php if($penggal1): ?>
                                                                                    <span class="me-3"><strong>P1:</strong>
                                                                                        <?php if($penggal1->markah == '1'): ?>
                                                                                            <span class="badge bg-warning text-dark">1</span>
                                                                                        <?php elseif($penggal1->markah == '2'): ?>
                                                                                            <span class="badge bg-info text-dark">2</span>
                                                                                        <?php else: ?>
                                                                                            <span class="badge bg-success">3</span>
                                                                                        <?php endif; ?>
                                                                                    </span>
                                                                                <?php endif; ?>
                                                                                <?php if($penggal2): ?>
                                                                                    <span><strong>P2:</strong>
                                                                                        <?php if($penggal2->markah == '1'): ?>
                                                                                            <span class="badge bg-warning text-dark">1</span>
                                                                                        <?php elseif($penggal2->markah == '2'): ?>
                                                                                            <span class="badge bg-info text-dark">2</span>
                                                                                        <?php else: ?>
                                                                                            <span class="badge bg-success">3</span>
                                                                                        <?php endif; ?>
                                                                                    </span>
                                                                                <?php endif; ?>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php elseif($isPratahfiz): ?>
                                                            
                                                            <?php
                                                                $pratahfizCriteria = [
                                                                    'Al-Fatihah', 'An-Nas', 'Al-Falaq', 'Al-Ikhlas', 'Al-Masad',
                                                                    'An-Nasr', 'Al-Kafirun', 'Al-Kawthar', 'Al-Ma\'un', 'Quraysh',
                                                                    'Al-Fil', 'Al-Humazah', 'Al-\'Asr', 'At-Takathur', 'Al-Qari\'ah',
                                                                    'Al-\'Adiyat', 'Al-Zalzalah', 'Al-Bayyinah', 'Al-Qadr'
                                                                ];
                                                            ?>
                                                            <?php $__currentLoopData = $pratahfizCriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $criteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php
                                                                    $itemLabel = $criteria;
                                                                    $itemId = str_replace(['\'', ' ', '-'], '_', $criteria);
                                                                    $penggal1Key = $itemLabel . '_Penggal 1';
                                                                    $penggal2Key = $itemLabel . '_Penggal 2';
                                                                    $penggal1 = $prestasi->has($penggal1Key) ? $prestasi->get($penggal1Key)->first() : null;
                                                                    $penggal2 = $prestasi->has($penggal2Key) ? $prestasi->get($penggal2Key)->first() : null;
                                                                ?>
                                                                <tr>
                                                                    <td class="text-center fw-semibold"><?php echo e($index + 1); ?></td>
                                                                    <td class="fw-semibold"><?php echo e($itemLabel); ?></td>
                                                                    <td>
                                                                        <div class="d-flex justify-content-center gap-3">
                                                                            <div class="form-check">
                                                                                <input class="form-check-input" type="radio"
                                                                                       name="assessments[<?php echo e($itemLabel); ?>]"
                                                                                       value="1"
                                                                                       id="item<?php echo e($itemId); ?>_1">
                                                                                <label class="form-check-label" for="item<?php echo e($itemId); ?>_1">
                                                                                    <span class="badge bg-warning text-dark">1</span> Ansur Maju
                                                                                </label>
                                                                            </div>
                                                                            <div class="form-check">
                                                                                <input class="form-check-input" type="radio"
                                                                                       name="assessments[<?php echo e($itemLabel); ?>]"
                                                                                       value="2"
                                                                                       id="item<?php echo e($itemId); ?>_2">
                                                                                <label class="form-check-label" for="item<?php echo e($itemId); ?>_2">
                                                                                    <span class="badge bg-info text-dark">2</span> Maju
                                                                                </label>
                                                                            </div>
                                                                            <div class="form-check">
                                                                                <input class="form-check-input" type="radio"
                                                                                       name="assessments[<?php echo e($itemLabel); ?>]"
                                                                                       value="3"
                                                                                       id="item<?php echo e($itemId); ?>_3">
                                                                                <label class="form-check-label" for="item<?php echo e($itemId); ?>_3">
                                                                                    <span class="badge bg-success">3</span> Sangat Maju
                                                                                </label>
                                                                            </div>
                                                                        </div>
                                                                        <?php if($penggal1 || $penggal2): ?>
                                                                            <div class="mt-2 small text-muted">
                                                                                <?php if($penggal1): ?>
                                                                                    <span class="me-3"><strong>P1:</strong>
                                                                                        <?php if($penggal1->markah == '1'): ?>
                                                                                            <span class="badge bg-warning text-dark">1</span>
                                                                                        <?php elseif($penggal1->markah == '2'): ?>
                                                                                            <span class="badge bg-info text-dark">2</span>
                                                                                        <?php else: ?>
                                                                                            <span class="badge bg-success">3</span>
                                                                                        <?php endif; ?>
                                                                                    </span>
                                                                                <?php endif; ?>
                                                                                <?php if($penggal2): ?>
                                                                                    <span><strong>P2:</strong>
                                                                                        <?php if($penggal2->markah == '1'): ?>
                                                                                            <span class="badge bg-warning text-dark">1</span>
                                                                                        <?php elseif($penggal2->markah == '2'): ?>
                                                                                            <span class="badge bg-info text-dark">2</span>
                                                                                        <?php else: ?>
                                                                                            <span class="badge bg-success">3</span>
                                                                                        <?php endif; ?>
                                                                                    </span>
                                                                                <?php endif; ?>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </tbody>
                                                </table>
                                            </div>

                                            <!-- Submit Button -->
                                            <div class="d-flex justify-content-end mt-4">
                                                <button type="submit" class="btn btn-primary btn-lg">
                                                    <i class="bi bi-save me-2"></i>Simpan Penilaian
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            <?php elseif($selectedClass && $selectedStudent && $selectedSubjek): ?>
                                <div class="card shadow-sm border-0 rounded-4 mb-4">
                                    <div class="card-body text-center text-muted py-5">
                                        <i class="bi bi-exclamation-circle" style="font-size: 3rem;"></i>
                                        <p class="mt-3">Tiada senarai ayat untuk subjek ini.</p>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <!-- Information Box -->
                            <?php if(!$selectedClass): ?>
                                <div class="card shadow-sm border-0 rounded-4 mb-4">
                                    <div class="card-body text-center text-muted py-5">
                                        <i class="bi bi-info-circle" style="font-size: 3rem;"></i>
                                        <p class="mt-3">Sila pilih kelas, murid dan subjek untuk mula menilai prestasi.</p>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Update hidden penggal field when dropdown changes
    function updatePenggalValue() {
        const penggalSelect = document.getElementById('penggal');
        const penggalInput = document.getElementById('penggalInput');
        if (penggalSelect && penggalInput) {
            const selectedValue = penggalSelect.value;
            penggalInput.value = selectedValue;
            // Add visual feedback
            if (selectedValue) {
                penggalSelect.classList.remove('is-invalid');
                penggalSelect.classList.add('is-valid');
            } else {
                penggalSelect.classList.remove('is-valid');
                penggalSelect.classList.add('is-invalid');
            }
        }
    }

    // Enhanced subject ID lookup with fallback
    function fetchSubjectIdWithFallback() {
        return new Promise((resolve, reject) => {
            const subjectIdInput = document.getElementById('subject_id');
            const selectedSubjek = '<?php echo e($selectedSubjek); ?>';

            if (!selectedSubjek) {
                reject('No subject selected');
                return;
            }

            // Try AJAX first
            fetch('/api/get-subject-id?nama_subjek=' + encodeURIComponent('<?php echo e($selectedSubjek); ?>'))
                .then(response => {
                    if (!response.ok) throw new Error('Network response was not ok: ' + response.status);
                    return response.json();
                })
                .then(data => {
                    if (data.success && data.subject_id) {
                        subjectIdInput.value = data.subject_id;
                        console.log('Subject ID successfully retrieved via API:', data.subject_id);
                        resolve(data.subject_id);
                    } else {
                        console.error('Subject ID lookup failed:', data.error || 'Unknown error');
                        throw new Error(data.error || 'Subject not found');
                    }
                })
                .catch(error => {
                    console.error('Error fetching subject ID via primary API:', error);

                    // Fallback 1: try to get from existing prestasi records
                    <?php if($prestasi->isNotEmpty() && $prestasi->first()->subject_id): ?>
                        const fallbackId = '<?php echo e($prestasi->first()->subject_id); ?>';
                        subjectIdInput.value = fallbackId;
                        console.log('Using fallback subject ID from prestasi records:', fallbackId);
                        resolve(fallbackId);
                    <?php elseif($prestasi->isNotEmpty() && $prestasi->first()->subjek_id): ?>
                        // Additional fallback for older records
                        const fallbackId = '<?php echo e($prestasi->first()->subjek_id); ?>';
                        subjectIdInput.value = fallbackId;
                        console.log('Using fallback subject ID from subjek_id:', fallbackId);
                        resolve(fallbackId);
                    <?php else: ?>
                        // Fallback 2: try to find subject by name directly
                        fetch('/api/subjects-by-name?nama_subjek=' + encodeURIComponent(selectedSubjek))
                            .then(response => response.json())
                            .then(data => {
                                if (data.success && data.subjects && data.subjects.length > 0) {
                                    subjectIdInput.value = data.subjects[0].id;
                                    console.log('Using fallback subject ID from subjects-by-name API:', data.subjects[0].id);
                                    resolve(data.subjects[0].id);
                                } else {
                                    // Fallback 3: try to get subject ID from subjek table directly
                                    console.error('All API fallbacks failed, attempting direct subject lookup');
                                    reject('Could not determine subject ID after multiple attempts');
                                }
                            })
                            .catch(fallbackError => {
                                console.error('All subject ID lookup methods failed:', fallbackError);
                                reject('Could not determine subject ID');
                            });
                    <?php endif; ?>
                });
        });
    }

    // Set subject ID when page loads
    document.addEventListener('DOMContentLoaded', function() {
        const subjectIdInput = document.getElementById('subject_id');
        const selectedSubjek = '<?php echo e($selectedSubjek); ?>';

        if (subjectIdInput && selectedSubjek) {
            fetchSubjectIdWithFallback()
                .then(subjectId => {
                    console.log('Subject ID successfully set to:', subjectId);
                })
                .catch(error => {
                    console.error('Failed to set subject ID:', error);
                    // Show warning to user
                    const alertDiv = document.createElement('div');
                    alertDiv.className = 'alert alert-warning mt-3';
                    alertDiv.innerHTML = `
                        <i class="bi bi-exclamation-triangle me-2"></i>
                        <strong>Amaran:</strong> Subject ID tidak dapat dijumpai untuk "${selectedSubjek}".
                        Penilaian mungkin tidak dapat disimpan. Sila muat semula halaman atau pilih subjek semula.
                    `;
                    // Insert after the subject select
                    const subjectSelect = document.getElementById('subjek');
                    if (subjectSelect) {
                        subjectSelect.parentNode.insertBefore(alertDiv, subjectSelect.nextSibling);
                    }
                });
        }
    });

    // Add form validation and AJAX submission
    document.addEventListener('DOMContentLoaded', function() {
        const form = document.querySelector('form[action="<?php echo e(route("guru.prestasiMurid.store")); ?>"]');
        if (form) {
            form.addEventListener('submit', async function(e) {
                e.preventDefault(); // Prevent default form submission
                const subjectIdInput = document.getElementById('subject_id');
                const penggalInput = document.getElementById('penggalInput');
                const penggalSelect = document.getElementById('penggal');

                // Ensure subject ID is set
                if (!subjectIdInput.value) {
                    try {
                        await fetchSubjectIdWithFallback();
                    } catch (error) {
                        alert('Subject ID tidak dapat diperoleh. Sila muat semula halaman.');
                        return false;
                    }
                }

                // Validate subject ID
                if (!subjectIdInput || !subjectIdInput.value) {
                    alert('Subject ID tidak dijumpai. Sila muat semula halaman atau pilih subjek semula.');
                    if (penggalSelect) penggalSelect.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    return false;
                }

                // Validate penggal
                if (!penggalInput || !penggalInput.value) {
                    alert('Sila pilih Penggal sebelum menyimpan.');
                    if (penggalSelect) {
                        penggalSelect.focus();
                        penggalSelect.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        penggalSelect.classList.add('is-invalid');
                    }
                    return false;
                }

                // Check if any assessments are selected
                const assessments = form.querySelectorAll('input[name^="assessments"]:checked');
                if (assessments.length === 0) {
                    if (!confirm('Tiada penilaian dipilih. Adakah anda pasti ingin menyimpan penilaian kosong?')) {
                        return false;
                    }
                }

                // Collect form data
                const formData = new FormData(form);

                // Submit via AJAX
                fetch(form.action, {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    console.log('Response data:', data);
                    if (data.success) {
                        alert('BERJAYA DISIMPAN!');
                        // Optionally reload the page or update UI
                        location.reload();
                    } else {
                        alert('Ralat: ' + (data.message || 'Gagal menyimpan data'));
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Ralat menyimpan data. Sila cuba lagi.');
                });

                return false;
            });
        }
    });
</script>

<!-- Success Modal -->
<div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title" id="successModalLabel">
                    <i class="bi bi-check-circle me-2"></i>Berjaya!
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center">
                <i class="bi bi-check-circle-fill text-success" style="font-size: 3rem;"></i>
                <p class="mt-3 mb-0" id="successMessage">Penilaian prestasi berjaya disimpan.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success" data-bs-dismiss="modal">OK</button>
            </div>
        </div>
    </div>
</div>

<script>
    // Show success modal if success message exists
    <?php if(session('success')): ?>
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Success message found:', '<?php echo e(session("success")); ?>');
            alert('<?php echo e(session("success")); ?>');
        });
    <?php endif; ?>
</script>
<style>
    .form-check-input:checked {
        background-color: #0d6efd;
        border-color: #0d6efd;
    }

    .table th {
        background-color: #e7f1ff;
    }

    .badge {
        font-size: 0.8rem;
        padding: 0.3rem 0.6rem;
    }

    /* Fix tab text readability */
    .nav-tabs .nav-link.active {
        color: #000 !important;
        background-color: rgba(255, 255, 255, 0.9) !important;
        border-color: #dee2e6 #dee2e6 #fff !important;
    }

    .nav-tabs .nav-link {
        color: #fff !important;
    }

    .nav-tabs .nav-link:hover {
        color: rgba(255, 255, 255, 0.8) !important;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pastisumayyah\resources\views/guru/prestasiMurid.blade.php ENDPATH**/ ?>