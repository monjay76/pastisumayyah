<?php $__env->startSection('title', 'Laporan'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h4>Laporan</h4>
    <div style="background:#fff; padding:15px; border-radius:8px;">
        <p>Placeholder: Papar laporan murid di sini.</p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pastisumayyah\resources\views/guru/laporan.blade.php ENDPATH**/ ?>