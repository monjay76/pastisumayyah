<?php $__env->startSection('title', 'Senarai Murid'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <div class="row mt-4">
        <div class="col-12">
            <div class="card shadow-sm border-0 rounded-4">
                <div class="card-header bg-primary text-white fw-semibold">
                    <i class="bi bi-people-fill me-2"></i> Senarai Murid
                </div>
                <div class="card-body">
                    <?php if($murids->count()): ?>
                        <table class="table table-striped align-middle">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>MyKid ID</th>
                                    <th>Nama Murid</th>
                                    <th>Kelas</th>
                                    <th>Tarikh Lahir</th>
                                    <th>Alamat</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $murids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $murid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($murid->MyKidID); ?></td>
                                        <td><?php echo e($murid->namaMurid); ?></td>
                                        <td><?php echo e($murid->kelas); ?></td>
                                        <td><?php echo e($murid->tarikhLahir ? date('d/m/Y', strtotime($murid->tarikhLahir)) : '-'); ?></td>
                                        <td><?php echo e($murid->alamat); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p class="text-muted mb-0">Tiada murid didaftarkan lagi.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pastisumayyah\resources\views/pentadbir/senaraiMurid.blade.php ENDPATH**/ ?>