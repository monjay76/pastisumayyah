<?php $__env->startSection('title', 'Aktiviti Tahunan'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
	<div class="row mt-4">
		<div class="col-12">
			<div class="card shadow-sm border-0 rounded-4">
				<div class="card-header bg-primary text-white fw-semibold">
					<i class="bi bi-calendar-event me-2"></i> Aktiviti Tahunan
					<?php if(isset($selectedMonth)): ?>
						- <?php echo e($monthName); ?>

					<?php endif; ?>
				</div>
				<div class="card-body">
					<?php if(session('success')): ?>
						<div class="alert alert-success"><?php echo e(session('success')); ?></div>
					<?php endif; ?>
					<?php if(session('error')): ?>
						<div class="alert alert-danger"><?php echo e(session('error')); ?></div>
					<?php endif; ?>
					<?php if(isset($selectedMonth)): ?>
						<!-- Month specific content -->
						<div class="mb-3">
							<a href="<?php echo e(route('pentadbir.aktivitiTahunan')); ?>" class="btn btn-secondary">Kembali ke Aktiviti Tahunan</a>
						</div>
						<?php if($images->count()): ?>
							<div class="row">
								<?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="col-md-4 col-sm-6 mb-4">
										<div class="card h-100">
											<img src="<?php echo e(asset('storage/' . $image->path)); ?>" class="card-img-top" alt="Aktiviti <?php echo e($monthName); ?>">
											<div class="card-body">
												<p class="card-text">Tarikh: <?php echo e(date('d/m/Y', strtotime($image->tarikh))); ?></p>
											</div>
										</div>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						<?php else: ?>
							<p class="text-muted mb-0">Tiada gambar untuk bulan ini.</p>
						<?php endif; ?>
					<?php else: ?>
						<!-- Month selection -->
						<h5>Pilih Bulan</h5>
						<div class="row mb-3">
							<div class="col-md-6">
								<label for="month" class="form-label">Bulan</label>
								<select class="form-select" id="month" required>
									<option value="">Pilih Bulan</option>
									<?php
										$months = [
											'Januari', 'Februari', 'Mac', 'April', 'Mei', 'Jun',
											'Julai', 'Ogos', 'September', 'Oktober', 'November', 'Disember'
										];
									?>
									<?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($index + 1); ?>"><?php echo e($month); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
						</div>
						<button type="button" class="btn btn-primary" onclick="selectMonth()">Pilih Bulan</button>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</div>

<script>
function selectMonth() {
	const month = document.getElementById('month').value;
	if (month) {
		window.location.href = '<?php echo e(url("pentadbir/aktiviti-tahunan")); ?>/' + month;
	} else {
		alert('Sila pilih bulan terlebih dahulu.');
	}
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pastisumayyah\resources\views/pentadbir/aktivitiTahunan.blade.php ENDPATH**/ ?>