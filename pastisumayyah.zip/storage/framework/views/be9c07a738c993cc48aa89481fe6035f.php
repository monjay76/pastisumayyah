<?php $__env->startSection('title', 'Profil Murid'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <div class="row mt-4">
        <div class="col-12">
            <div class="card shadow-sm border-0 rounded-4">
                <div class="card-header bg-primary text-white fw-semibold">
                    <i class="bi bi-person-fill me-2"></i> Profil Murid
                </div>
                <div class="card-body">
                    <?php if(!isset($selectedClass) || !$selectedClass): ?>
                        <h5>Pilih Kelas</h5>
                        <div class="row">
                            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3 mb-3">
                                    <a href="<?php echo e(route('guru.profilMurid', ['kelas' => $class])); ?>" class="btn btn-outline-primary w-100">
                                        <?php echo e($class); ?>

                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <div class="mb-3">
                            <a href="<?php echo e(route('guru.profilMurid')); ?>" class="btn btn-secondary">
                                <i class="bi bi-arrow-left"></i> Kembali 
                            </a>
                        </div>
                        <?php if(!isset($selectedStudent) || !$selectedStudent): ?>
                            <h5>Pilih Murid dari Kelas <?php echo e($selectedClass); ?></h5>
                            <?php if($students->count()): ?>
                                <table class="table table-striped align-middle">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>MyKid ID</th>
                                            <th>Nama Murid</th>
                                            <th>Kelas</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($index + 1); ?></td>
                                                <td><?php echo e($student->MyKidID); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('guru.profilMurid', ['kelas' => $selectedClass, 'murid' => $student->MyKidID])); ?>">
                                                        <?php echo e($student->namaMurid); ?>

                                                    </a>
                                                </td>
                                                <td><?php echo e($student->kelas); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <p class="text-muted mb-0">Tiada murid didaftarkan lagi.</p>
                            <?php endif; ?>
                        <?php else: ?>
                            <h5>Maklumat Peribadi Murid</h5>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="text-center">
                                        <h6>Gambar Profil</h6>
                                        <?php if($selectedStudent->gambar_profil): ?>
                                            <img src="<?php echo e(asset('storage/' . $selectedStudent->gambar_profil)); ?>" alt="Gambar Profil" class="img-fluid rounded-circle mb-3" style="width: 150px; height: 150px; object-fit: cover;">
                                        <?php else: ?>
                                            <div class="bg-light rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 150px; height: 150px;">
                                                <i class="bi bi-person-fill text-muted" style="font-size: 3rem;"></i>
                                            </div>
                                        <?php endif; ?>
                                        <form action="<?php echo e(route('guru.updateProfilePicture', $selectedStudent->MyKidID)); ?>" method="POST" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="mb-3">
                                                <input type="file" name="gambar_profil" class="form-control" accept="image/*" required>
                                            </div>
                                            <button type="submit" class="btn btn-primary">Kemas Kini Gambar</button>
                                        </form>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <table class="table table-borderless">
                                        <tr>
                                            <th>MyKid ID:</th>
                                            <td><?php echo e($selectedStudent->MyKidID); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Nama Murid:</th>
                                            <td><?php echo e($selectedStudent->namaMurid); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Kelas:</th>
                                            <td><?php echo e($selectedStudent->kelas); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Tarikh Lahir:</th>
                                            <td><?php echo e($selectedStudent->tarikhLahir ? date('d/m/Y', strtotime($selectedStudent->tarikhLahir)) : '-'); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Alamat:</th>
                                            <td><?php echo e($selectedStudent->alamat); ?></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pastisumayyah\resources\views/guru/profilMurid.blade.php ENDPATH**/ ?>