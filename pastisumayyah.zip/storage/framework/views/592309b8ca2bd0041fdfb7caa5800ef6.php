<?php $__env->startSection('title', 'Profil Murid'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <div class="row mt-4">
        <div class="col-12">
            <div class="card shadow-sm border-0 rounded-4">
                <div class="card-header bg-primary text-white fw-semibold">
                    <i class="bi bi-person-fill me-2"></i> Profil Murid
                </div>
                <div class="card-body">
                    <?php if(!$selectedClass): ?>
                        <h5>Pilih Kelas</h5>
                        <div class="row">
                            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3 mb-3">
                                    <a href="<?php echo e(route('pentadbir.profilMurid', ['kelas' => $class])); ?>" class="btn btn-outline-primary w-100">
                                        <?php echo e($class); ?>

                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <div class="mb-3">
                            <a href="<?php echo e(route('pentadbir.profilMurid')); ?>" class="btn btn-secondary">
                                <i class="bi bi-arrow-left"></i> Kembali ke Pilihan Kelas
                            </a>
                        </div>
                        <?php if(!$selectedStudent): ?>
                            <h5>Senarai Murid</h5>
                            <?php if($students->count()): ?>
                                <table class="table table-striped align-middle">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>MyKid ID</th>
                                            <th>Nama Murid</th>
                                            <th>Kelas</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($index + 1); ?></td>
                                                <td><?php echo e($student->MyKidID); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('pentadbir.profilMurid', ['kelas' => $selectedClass, 'murid' => $student->MyKidID])); ?>">
                                                        <?php echo e($student->namaMurid); ?>

                                                    </a>
                                                </td>
                                                <td><?php echo e($student->kelas); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <p class="text-muted mb-0">Tiada murid didaftarkan lagi.</p>
                            <?php endif; ?>
                        <?php else: ?>
                            <h5>Maklumat Peribadi Murid</h5>
                            <div class="row">
                                <div class="col-md-6">
                                    <table class="table table-borderless">
                                        <tr>
                                            <th>MyKid ID:</th>
                                            <td><?php echo e($selectedStudent->MyKidID); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Nama Murid:</th>
                                            <td><?php echo e($selectedStudent->namaMurid); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Kelas:</th>
                                            <td><?php echo e($selectedStudent->kelas); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Tarikh Lahir:</th>
                                            <td><?php echo e($selectedStudent->tarikhLahir ? date('d/m/Y', strtotime($selectedStudent->tarikhLahir)) : '-'); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Alamat:</th>
                                            <td><?php echo e($selectedStudent->alamat); ?></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pastisumayyah\resources\views/pentadbir/profilMurid.blade.php ENDPATH**/ ?>